package com.restaurant;

import com.restaurant.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class InfoScreen extends Activity {


	public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        //load layout
	        setContentView(R.layout.info);

		//ImageView i1;
		//i1 = (ImageView) findViewById(R.id.imageView2);


			};

}
