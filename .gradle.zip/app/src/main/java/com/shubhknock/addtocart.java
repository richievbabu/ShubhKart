package com.shubhknock;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import android.view.View.OnClickListener;;

public class addtocart extends Activity implements OnClickListener {
	TextView orderitem;
	EditText Quantity;
	 Button Place_Order;
	 String tempstring;
	 Integer i;
	 String s;
	myDatabase orderHelper;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        orderHelper = new myDatabase(addtocart.this);
        
     // initialise form widget
        setContentView(R.layout.addtocart);

        orderitem =(TextView)findViewById(R.id.orderitem);
        Quantity =(EditText)findViewById(R.id.Quantity);
        Place_Order =(Button)findViewById(R.id.Place_Order_btn);

        
        s= getIntent().getStringExtra("order");
      
        String[] temp;
    
        String delimiter = "-";
        
        // given string will be split by the argument delimiter provided. 
        temp = s.split(delimiter);
        // print substrings 
      
        s=temp[0];
       
        // s=orderdata.toString();
       

       orderitem.setText("Your order :- "+s);
		Quantity.setRawInputType(InputType.TYPE_CLASS_NUMBER);
		Place_Order.setClickable(true);
		Place_Order.setOnClickListener(this);
      
   	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		 Place_Order.setClickable(true);
		orderHelper = new myDatabase(addtocart.this);
			//orderHelper.getWritableDatabase();
	}
	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		 Place_Order.setClickable(true);

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		//on button click place order
			
			Place_Order.setClickable(false);
			tempstring=Quantity.getText().toString();
		
			i=Integer.parseInt(tempstring); 
			Toast.makeText(addtocart.this, s, Toast.LENGTH_LONG);
			String  temps=s;
			s=s+"  "+ "quantity"+"  "+ i;

			//add data to model class object
			boolean add = ModelClass.al.add(s);
		
			//	adding the data 
			orderHelper.addOrder(s);
		Toast.makeText(addtocart.this, "Successfully added to addtocart"  ,Toast.LENGTH_LONG ).show();
		Intent mIntent = new Intent(addtocart.this,mycart.class);
			startActivity(mIntent);
			finish();
		
	}
	public boolean checkType()
	{
		return false;
	}
	
	public void onStop(){
		super.onStop();
		orderHelper.close();
		//orderHelper.cursor.close();
	}
}