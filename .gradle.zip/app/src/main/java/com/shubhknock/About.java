package com.shubhknock;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class About extends Activity{

Button getfeedback;
	public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        //load layout
	        setContentView(R.layout.about);
		getfeedback=(Button)findViewById(R.id.feedbutton);

		getfeedback.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				//starting new activity on button click
				Intent i =new Intent(About.this,Feed.class);
				startActivity(i);
			}
		});

			};
	}


