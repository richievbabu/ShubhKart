package com.shubhknock;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

/**
 * Created by Administrator on 3/28/2017.
 */
public class Feed extends Activity {
    private RadioGroup radioFeedGroup;
    private RadioButton radioFeedButton;
    private Button btnDisplay;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feed);

        addListenerOnButton();

    }

    public void addListenerOnButton() {

        radioFeedGroup = (RadioGroup) findViewById(R.id.radiofeed);
        btnDisplay = (Button) findViewById(R.id.btnDisplay);

        btnDisplay.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // get selected radio button from radioGroup
                int selectedId = radioFeedGroup.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                radioFeedButton = (RadioButton) findViewById(selectedId);

                Toast.makeText(Feed.this,
                       "Your feedback has been submitted", Toast.LENGTH_SHORT).show();

            }

        });

    }

}
